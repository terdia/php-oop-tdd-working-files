<?php


namespace App\Exception;


class InvalidLogLevelArgument extends BaseException
{

}