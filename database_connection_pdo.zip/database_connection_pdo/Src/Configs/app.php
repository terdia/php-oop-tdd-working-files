<?php

return [

    'app_name' => 'Bug Report App',
    'env' => 'local',
    'debug' => true,
    'log_path' => __DIR__ . '/../Logger',
];