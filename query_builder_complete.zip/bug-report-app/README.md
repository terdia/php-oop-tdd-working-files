# bug-report-app

Build A bug Tracking App with PHP OOP no Dependencies 

Your support is needed, [Enrol in Course](https://devscreencast.com/courses/build-a-bug-tracking-app-with-php-oop-no-dependencies).
