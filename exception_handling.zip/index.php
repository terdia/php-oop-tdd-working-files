<?php

require_once __DIR__ .'/vendor/autoload.php';

include_once __DIR__ . '/Src/Exceptions/exception.php';

$logger = new \App\Logger\Logger();

$connection = (new \App\Database\MySQLiConnection())->connect();

$dbHandler = new \App\Database\MySQLiQueryBuilder($connection);

$serialize = serialize([
    'report_type' => 'booking failed',
    'user' => 2,
    'message' => 'I found a bug when making a booking see photo',
    'image_link' => 'image',
    'created_at' => date('Y-m-d H:i:s'),
]);
echo $serialize;

var_dump(unserialize($serialize));
exit;


$reportId = $dbHandler->table('reports')->create([
    'report_type' => 'booking failed',
    'user' => 2,
    'message' => 'I found a bug when making a booking see photo',
    'image_link' => 'image',
    'created_at' => date('Y-m-d H:i:s'),
]);

var_dump($reportId);
var_dump($dbHandler->raw("SELECT * FROM reports")->get());

