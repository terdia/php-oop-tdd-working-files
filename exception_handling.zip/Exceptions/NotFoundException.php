<?php
declare(strict_types=1);

namespace App\Exception;

use HttpException;
use Throwable;

class NotFoundException extends HttpException implements Throwable
{

}