<?php
declare(strict_types=1);

namespace App\Exception;

use App\Exceptions\Main;

class DatabaseConnectionException extends Main {

}